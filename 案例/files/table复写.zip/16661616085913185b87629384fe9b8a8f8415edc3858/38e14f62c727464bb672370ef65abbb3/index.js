const NewTables = ecodeSDK.imp(NewTables)
const {Provider} = mobxReact;
const allStore = ecodeSDK.imp(allStore);

class NewTableCom extends React.Component {
  render(){
    return (
      <Provider {...allStore}>
        <NewTables {...this.props} />
      </Provider>
    )
  }
}

// 导出到全局
ecodeSDK.setCom('${appId}','NewTableCom',NewTableCom);