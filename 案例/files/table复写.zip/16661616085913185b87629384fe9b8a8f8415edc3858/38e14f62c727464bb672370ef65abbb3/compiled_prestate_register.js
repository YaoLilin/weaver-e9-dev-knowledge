"use strict";

var enable = true; // 从全局导入

var NewCom = function NewCom(props) {
  var acParams = {
    appId: '${appId}',
    name: 'NewTableCom',
    isPage: false,
    noCss: true,
    props: props
  };
  var NewCom = props.Com;
  return window.comsMobx ? ecodeSDK.getAsyncCom(acParams) : React.createElement(NewCom, props);
};

ecodeSDK.overwriteClassFnQueueMapSet('Table', {
  fn: function fn(Com, newProps) {
    if (!enable) return;
    var hash = window.location.hash;
    if (!hash.startsWith("#/main/portal/portal-3-1")) return;
    newProps.Com = Com;
    if (newProps._noOverwrite) return;
    return {
      com: NewCom,
      props: newProps
    };
  }
});