"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table;

var NewTables =
/*#__PURE__*/
function (_React$Component) {
  _inherits(NewTables, _React$Component);

  function NewTables(props) {
    var _this;

    _classCallCheck(this, NewTables);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(NewTables).call(this, props));
    _this.states = {};
    return _this;
  }

  _createClass(NewTables, [{
    key: "componentDidMount",
    value: function componentDidMount() {}
  }, {
    key: "render",
    value: function render() {
      var newProps = _objectSpread({}, this.props);

      var col = newProps.columns;
      debugger;
      var columns = [];

      for (var i = 0; i < col.length; i++) {
        var cows = {
          dataIndex: "",
          key: "",
          width: "",
          title: "title",
          className: ''
        };
        cows.dataIndex = col[i].dataIndex;
        cows.key = col[i].key;
        cows.width = col[i].width;
        cows.className = 'dev-tables dev-tables' + col[i].dataIndex;

        if (col[i].dataIndex == 'imgSymbol') {
          cows.render = function (text, record) {
            return React.createElement("span", {
              class: "dev-tables-img"
            });
          };

          cows.width = '20px';
        }

        columns.push(cows);
      }

      var datas = [];

      for (var _i = 0; _i < newProps.dataSource.length; _i++) {
        var d = {
          key: '',
          docsubject: '',
          doccreatedate: '',
          link: ''
        };
        d.key = _i;
        d.docsubject = newProps.dataSource[_i].docsubject.name;
        d.doccreatedate = newProps.dataSource[_i].doccreatedate;
        d.link = newProps.dataSource[_i].docsubject.link;
        datas.push(d);
      }

      return React.createElement("div", {
        className: "dev-table-main"
      }, React.createElement(Table, {
        columns: columns,
        dataSource: datas,
        _noOverwrite: true,
        pagination: false,
        showHeader: false
      }));
    }
  }]);

  return NewTables;
}(React.Component);