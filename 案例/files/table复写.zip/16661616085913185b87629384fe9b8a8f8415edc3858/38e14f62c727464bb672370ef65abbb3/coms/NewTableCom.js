const {Table} = antd;

class NewTables extends React.Component {
  constructor(props) {
    super(props);
    this.states = {
        
    }
  }

  componentDidMount() {

  }

  render() {
    
    let newProps = { ...this.props };
    const col = newProps.columns;
    debugger
    let columns = [];
    for (let i = 0; i < col.length; i++) {
      let cows = {
        dataIndex: "",
        key: "",
        width: "",
        title: "title",
        className : ''
      }
      cows.dataIndex = col[i].dataIndex;
      cows.key = col[i].key;
      cows.width =  col[i].width;
      cows.className ='dev-tables dev-tables'+col[i].dataIndex;

      if(col[i].dataIndex == 'imgSymbol'){
        cows.render=(text,record)=>{
          return(
            <span class='dev-tables-img'></span>
          );
        }
        cows.width = '20px';
      }
  
      columns.push(cows);
    }

    let datas =[];
    for(let i=0;i<newProps.dataSource.length;i++){
      const d = {
        key:'',
        docsubject:'',
        doccreatedate:'',
        link:''
      }
      d.key = i;
      d.docsubject=newProps.dataSource[i].docsubject.name;
      d.doccreatedate = newProps.dataSource[i].doccreatedate;
      d.link = newProps.dataSource[i].docsubject.link

      datas.push(d);
    }
    
    return (
      <div className='dev-table-main'>
      <Table
        columns={columns}
        dataSource={datas}
        _noOverwrite
        pagination={false}
        showHeader={false}
        />
      </div>
     
    )
  }
}