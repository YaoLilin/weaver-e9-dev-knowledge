let enable = true;

// 从全局导入
const NewCom  = (props) => {
  const acParams = {
    appId : '${appId}',
    name:'NewTableCom',
    isPage:false,
    noCss:true,
    props,
  }
  
  const NewCom = props.Com;
  return window.comsMobx?ecodeSDK.getAsyncCom(acParams):(<NewCom {...props}/>);
}

ecodeSDK.overwriteClassFnQueueMapSet('Table',{
  fn:(Com,newProps) =>{
    if(!enable) return;
    const {hash} = window.location;
    if(!hash.startsWith("#/main/portal/portal-3-1")) return;
    newProps.Com = Com;
    if(newProps._noOverwrite) return;
    return{
      com:NewCom,
      props:newProps,
    }
  }
});
