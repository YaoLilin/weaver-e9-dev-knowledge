"use strict";

ecodeSDK.overwritePropsFnQueueMapSet('WeaDateGroup', {
  fn: function fn(props) {
    if (location.href.includes('/main/cube/search?customid=588')) {
      window.changeSearchConditon = function (startDate, endDate) {
        props.onChange(['6', startDate, endDate]);
      };
    }
  }
}); // ecodeSDK.overwriteClassFnQueueMapSet('WeaDateGroup',{
//     fn:(Com,props)=>{
//         debugger
//         if (!location.href.includes('/main/cube/search?customid=588') || props._noOverwirite){
//             return{
//                 com:Com,
//                 props:props
//             }
//         }
//         return{
//             com:customDateGroup,
//             props:props
//         }
//     }
// });
// const customDateGroup = (props)=>{
//     const params ={
//         appId:'${appId}',
//         name:'CustomDateGroup',
//         isPage:false,
//         noCss:true,
//         props
//     }
//     const NewCom = props.Com;
//     return window.comsMobx?ecodeSDK.getAsyncCom(params):(<NewCom {...props}/>);
// }