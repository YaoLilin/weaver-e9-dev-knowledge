const {WeaDateGroup} = ecCom;

class CustomDateGroup extends React.Component{

  constructor(props){
    super(props);
  }

  render(){
    return (
      <WeaDateGroup {...this.props} _noOverwirite onChange={(e)=>{
        debugger
        this.props.onChange(e);
      }}/>
    )
  }
}

ecodeSDK.setCom('${appId}','CustomDateGroup',CustomDateGroup);