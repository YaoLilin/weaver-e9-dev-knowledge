// 公文办理截止日期
let handleEndTime;
// 是否开启公文限时办理，如启用则进行超时提醒
let enableTimeLimit = true;
// 是否需要记录操作信息到建模，用于后续统计耗时
let isRecordInfo = false;
// 需要统计耗时的节点
let recordNodeIds = [];

/**
 * 重写公文流程中提交时选择节点的表格，添加办理期限字段
 */
ecodeSDK.overwriteClassFnQueueMapSet('WeaTable',{
  fn:(Com,props)=>{
    try{
      if(location.href.includes('spa/workflow/static4form/index.html') && props.ecId 
          && props.ecId.includes('WeaTable@gwk4pc') && isEnable() && !props._noOverwrite){
            console.log('isEnable')
          props.endTimeChange = t=>{
            handleEndTime = t;
          }
          props.enableTimeLimitChange = v =>{
            enableTimeLimit = v;
          }
          props.setRecordInfo = o =>{
            isRecordInfo = o.isRecordInfo;
            recordNodeIds = o.recordNodeIds;
          }
          return {com:customNodeListTable,props}
      }
    }catch(e){
      console.error('重写table组件出错',e)
    }
  }
});

function isEnable(){
  const formid = WfForm.getBaseInfo().formid;
  const config = ecodeSDK.getCom('${appId}','config');
  for(const item of config.workflowConfigs){
    if(item.formId === formid){
      return true;
    }
  }
}

const customNodeListTable = (props)=>{
    const params ={
        appId:'${appId}',
        name:'CustomNodeListTable',
        isPage:false,
        noCss:true,
        props
    }
    const NewCom = props.Com;
    return window.comsMobx?ecodeSDK.getAsyncCom(params):(<NewCom {...props}/>);
}


/**
 * @author 姚礼林
 */
ecodeSDK.rewriteApiParamsQueueSet({
  fn: (url, method, params) => {
    if (location.href.includes('spa/workflow/static4form/index.html') &&
         url.includes('api/odoc/odocrequest/flowNext')) {
      params.handleEndTime = handleEndTime;
      params.isRecordInfo = isRecordInfo?'1':'0';
      params.recordNodeIds = recordNodeIds.join(',');
      params.enableTimeLimit = enableTimeLimit ? '1' : '0';

    }
    return {
        url: url,
        method: method,
        params: params,
    }
  },
  desc: '拦截公文流程提交接口，添加办理截止时间参数到接口，后端记录截止时间到台账'
});

/**
 * @author 姚礼林
 * @desc 拦截公文流转按钮，校验办理实效字段必填
 */
ecodeSDK.overwritePropsFnQueueMapSet('Button',{
  fn:(props)=>{
    if(location.href.includes('spa/workflow/static4form/index.html') && props.ecId 
          && props.ecId.includes('OdocTransferDialog@ghs7ns_Button@cro4qy')){
        // 拦截公文流转按钮，校验办理实效字段必填
        const onClick = props.onClick;
        props.onClick = (e)=>{
          if(enableTimeLimit && isRecordInfo && !handleEndTime){
             WfForm.showConfirm("请填写办理时限", function(){});
             return;
          }
          onClick(e);
        }
    }
  }
});