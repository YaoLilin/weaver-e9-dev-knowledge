
const {Table,Switch} = antd;
const {WeaDatePicker,WeaTable} = ecCom;

/**
 * 重写提交选择节点列表，添加办理时限日期选择框
 */
class CustomNodeListTable extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      time : null,
      enableTimeLimit:true
    }
  }
  config = ecodeSDK.getCom('${appId}','config');

  getConfigNodeIds(){
    const nodeNames = this.getConfigNodeNames();
    if(nodeNames.length === 0){
      return [];
    }
    const {dataSource} = this.props;
    const nodeIds = [];
    dataSource.forEach(i => {
      if(nodeNames.some(n => n === i.nodename)){
        nodeIds.push(i.nodeid);
      }
    })
    return nodeIds;
  }

  getConfigNodeNames(){
    const formid = WfForm.getBaseInfo().formid;
    const config = ecodeSDK.getCom('${appId}','config');
    const workflowConfig = config.workflowConfigs.find( i => i.formId === formid);
    if(workflowConfig){
      return workflowConfig.nodeName;
    }
    return [];
  }

  isShowCustomCom(){
    const {rowSelection} = this.props;
    const configNodeIds = this.getConfigNodeIds();
    if(configNodeIds.length == 0){
      return false;
    }
    const isShow = rowSelection.selectedRowKeys.some(i => configNodeIds.includes(i));
    const recordNodeIds = rowSelection.selectedRowKeys.filter(i => configNodeIds.includes(i));
    this.props.setRecordInfo({isRecordInfo:isShow,recordNodeIds});
    return isShow;
  }

  handleTimeChange = (v)=>{
    this.props.endTimeChange(v);
    this.setState({time:v})
  }

  handleSwtichChange = (v)=>{
    this.props.enableTimeLimitChange(v);
    this.setState({enableTimeLimit:v});
    if(!v){
      this.handleTimeChange('');
    }
  }

  render(){
    const {time,enableTimeLimit} = this.state;

    return (
      <div>
        <WeaTable {...this.props} _noOverwrite/>
        {
          this.isShowCustomCom() && 
          <div style={{marginTop:10}}>
            <span>开启办理时限</span>
            <Switch style={{marginLeft:5}} checked={enableTimeLimit} onChange={this.handleSwtichChange} />
            {
              enableTimeLimit && 
                <>
                  <span style={{marginLeft:5}}>办理时限：</span> <WeaDatePicker format="yyyy-MM-dd HH:mm:ss" 
                        showTime={{ format: "HH:mm:ss" }}
                        value = {time}
                        onChange={this.handleTimeChange}/>
                  <span style={{color:'red',marginLeft:5}} className={'wea-f14'}>*</span>
               </>
            }
            
          </div>
        }
      </div>
    )
  }
}

ecodeSDK.setCom('${appId}','CustomNodeListTable',CustomNodeListTable);