"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table,
    Switch = _antd.Switch;
var _ecCom = ecCom,
    WeaDatePicker = _ecCom.WeaDatePicker,
    WeaTable = _ecCom.WeaTable;
/**
 * 重写提交选择节点列表，添加办理时限日期选择框
 */

var CustomNodeListTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(CustomNodeListTable, _React$Component);

  function CustomNodeListTable(props) {
    var _this;

    _classCallCheck(this, CustomNodeListTable);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(CustomNodeListTable).call(this, props));
    _this.config = ecodeSDK.getCom('${appId}', 'config');

    _this.handleTimeChange = function (v) {
      _this.props.endTimeChange(v);

      _this.setState({
        time: v
      });
    };

    _this.handleSwtichChange = function (v) {
      _this.props.enableTimeLimitChange(v);

      _this.setState({
        enableTimeLimit: v
      });

      if (!v) {
        _this.handleTimeChange('');
      }
    };

    _this.state = {
      time: null,
      enableTimeLimit: true
    };
    return _this;
  }

  _createClass(CustomNodeListTable, [{
    key: "getConfigNodeIds",
    value: function getConfigNodeIds() {
      var nodeNames = this.getConfigNodeNames();

      if (nodeNames.length === 0) {
        return [];
      }

      var dataSource = this.props.dataSource;
      var nodeIds = [];
      dataSource.forEach(function (i) {
        if (nodeNames.some(function (n) {
          return n === i.nodename;
        })) {
          nodeIds.push(i.nodeid);
        }
      });
      return nodeIds;
    }
  }, {
    key: "getConfigNodeNames",
    value: function getConfigNodeNames() {
      var formid = WfForm.getBaseInfo().formid;
      var config = ecodeSDK.getCom('${appId}', 'config');
      var workflowConfig = config.workflowConfigs.find(function (i) {
        return i.formId === formid;
      });

      if (workflowConfig) {
        return workflowConfig.nodeName;
      }

      return [];
    }
  }, {
    key: "isShowCustomCom",
    value: function isShowCustomCom() {
      var rowSelection = this.props.rowSelection;
      var configNodeIds = this.getConfigNodeIds();

      if (configNodeIds.length == 0) {
        return false;
      }

      var isShow = rowSelection.selectedRowKeys.some(function (i) {
        return configNodeIds.includes(i);
      });
      var recordNodeIds = rowSelection.selectedRowKeys.filter(function (i) {
        return configNodeIds.includes(i);
      });
      this.props.setRecordInfo({
        isRecordInfo: isShow,
        recordNodeIds: recordNodeIds
      });
      return isShow;
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          time = _this$state.time,
          enableTimeLimit = _this$state.enableTimeLimit;
      return React.createElement("div", null, React.createElement(WeaTable, _extends({}, this.props, {
        _noOverwrite: true
      })), this.isShowCustomCom() && React.createElement("div", {
        style: {
          marginTop: 10
        }
      }, React.createElement("span", null, "\u5F00\u542F\u529E\u7406\u65F6\u9650"), React.createElement(Switch, {
        style: {
          marginLeft: 5
        },
        checked: enableTimeLimit,
        onChange: this.handleSwtichChange
      }), enableTimeLimit && React.createElement(React.Fragment, null, React.createElement("span", {
        style: {
          marginLeft: 5
        }
      }, "\u529E\u7406\u65F6\u9650\uFF1A"), " ", React.createElement(WeaDatePicker, {
        format: "yyyy-MM-dd HH:mm:ss",
        showTime: {
          format: "HH:mm:ss"
        },
        value: time,
        onChange: this.handleTimeChange
      }), React.createElement("span", {
        style: {
          color: 'red',
          marginLeft: 5
        },
        className: 'wea-f14'
      }, "*"))));
    }
  }]);

  return CustomNodeListTable;
}(React.Component);

ecodeSDK.setCom('${appId}', 'CustomNodeListTable', CustomNodeListTable);