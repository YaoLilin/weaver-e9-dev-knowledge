const {observable,action} = mobx;
const {WeaTools} = ecCom;
const callApi = WeaTools.callApi;

class HrmStore{
    @observable data = [];

    @action 
    init = ()=>{
      callApi('/api/myhrm/getDepartmentHrm?departmentId=17').then(result=>{
        if(result && result.status==='S'){
          this.data = result.data;
        }
      })
    }
}

ecodeSDK.exp(HrmStore);