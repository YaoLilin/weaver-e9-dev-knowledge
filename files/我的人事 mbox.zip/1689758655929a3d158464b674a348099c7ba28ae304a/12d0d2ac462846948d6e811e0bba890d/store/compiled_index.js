"use strict";

ecodeSDK.imp(HrmStore);
var hrmStore = new HrmStore();
var allStore = {
  hrmStore: hrmStore
};
ecodeSDK.exp(allStore);