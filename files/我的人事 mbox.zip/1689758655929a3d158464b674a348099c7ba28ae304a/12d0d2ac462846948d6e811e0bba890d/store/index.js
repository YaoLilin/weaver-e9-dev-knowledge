
ecodeSDK.imp(HrmStore);
const hrmStore = new HrmStore();

const allStore={
  hrmStore,
}

ecodeSDK.exp(allStore);