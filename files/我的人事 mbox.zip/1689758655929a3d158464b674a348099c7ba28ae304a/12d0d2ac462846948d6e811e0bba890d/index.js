const HrmInfo = ecodeSDK.imp(HrmInfo);
const { Provider } = mobxReact;
const allStore = ecodeSDK.imp(allStore);

class Layout extends React.Component{

  render(){
    return (
      <Provider {...allStore}>
        <div style={{background:'rgb(249, 249, 249)',width:'100%',height:'100%'}}>
          <HrmInfo/>
        </div>
      </Provider>
    )
  }
}

ecodeSDK.setCom('${appId}','hrmInfo',Layout);