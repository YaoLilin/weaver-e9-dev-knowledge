"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaFormItem = _ecCom.WeaFormItem,
    WeaInput = _ecCom.WeaInput;

var HrmCard =
/*#__PURE__*/
function (_React$Component) {
  _inherits(HrmCard, _React$Component);

  function HrmCard(props) {
    _classCallCheck(this, HrmCard);

    return _possibleConstructorReturn(this, _getPrototypeOf(HrmCard).call(this, props));
  }

  _createClass(HrmCard, [{
    key: "render",
    value: function render() {
      var data = this.props.data;
      var imgSrc = '';

      if (data.sex === '0') {
        imgSrc = '/images/messageimages/temp/man_wev8.png';
      } else {
        imgSrc = '/images/messageimages/temp/women_wev8.png';
      }

      return React.createElement("div", {
        style: {
          width: '440px',
          padding: '20px',
          overflow: 'hidden'
        }
      }, React.createElement("div", {
        style: {
          width: '400px',
          background: 'white',
          padding: '20px',
          overflow: 'hidden',
          borderRadius: '12px'
        }
      }, React.createElement("div", {
        style: {
          float: 'left',
          width: '40%',
          textAlign: 'center'
        }
      }, React.createElement("img", {
        src: imgSrc,
        style: {
          height: 180
        }
      })), React.createElement("div", {
        style: {
          float: 'left',
          width: '60%'
        }
      }, React.createElement(WeaFormItem, {
        label: "\u59D3\u540D",
        labelCol: {
          span: 12
        },
        wrapperCol: {
          span: 12
        }
      }, React.createElement(WeaInput, {
        viewAttr: 1,
        value: data.lastname
      })), React.createElement(WeaFormItem, {
        label: "\u5C97\u4F4D",
        labelCol: {
          span: 12
        },
        wrapperCol: {
          span: 12
        }
      }, React.createElement(WeaInput, {
        viewAttr: 1,
        value: data.jobtitlename
      })), React.createElement(WeaFormItem, {
        label: "\u624B\u673A\u53F7",
        labelCol: {
          span: 12
        },
        wrapperCol: {
          span: 12
        }
      }, React.createElement(WeaInput, {
        viewAttr: 1,
        value: data.mobile
      })), React.createElement(WeaFormItem, {
        label: "\u5DE5\u4F5C\u5F00\u59CB\u65E5\u671F",
        labelCol: {
          span: 12
        },
        wrapperCol: {
          span: 12
        }
      }, React.createElement(WeaInput, {
        viewAttr: 1,
        value: data.workstartdate
      })))));
    }
  }]);

  return HrmCard;
}(React.Component);

ecodeSDK.exp(HrmCard);