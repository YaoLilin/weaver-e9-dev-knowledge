
const {WeaFormItem,WeaInput} = ecCom;

class HrmCard extends React.Component{
  constructor(props){
    super(props);
  }

  render(){
    const {data} = this.props;
    let imgSrc = '';
    if(data.sex === '0'){
      imgSrc = '/images/messageimages/temp/man_wev8.png';
    }else{
      imgSrc = '/images/messageimages/temp/women_wev8.png';
    }

    return(
      <div style={{width:'440px',padding:'20px',overflow:'hidden'}}>
        <div style={{width:'400px',background:'white',padding:'20px',overflow:'hidden',borderRadius:'12px'}}>
            <div style={{float:'left',width:'40%',textAlign:'center'}}>
              <img src={imgSrc} style={{height:180}}/>
            </div>
            <div style={{float:'left',width:'60%'}}>
              <WeaFormItem label="姓名"
                labelCol={{span: 12}}
                wrapperCol={{span: 12}}>
                <WeaInput viewAttr={1} value={data.lastname}/>
              </WeaFormItem>
              <WeaFormItem label="岗位"
                labelCol={{span: 12}}
                wrapperCol={{span: 12}}>  
                <WeaInput viewAttr={1} value={data.jobtitlename}/>
              </WeaFormItem>
              <WeaFormItem label="手机号"
                labelCol={{span: 12}}
                wrapperCol={{span: 12}}>
                <WeaInput viewAttr={1} value={data.mobile}/>
              </WeaFormItem>
              <WeaFormItem label="工作开始日期"
                labelCol={{span: 12}}
                wrapperCol={{span: 12}}>
                <WeaInput viewAttr={1} value={data.workstartdate}/>
              </WeaFormItem>
            </div>   
        </div>
      </div>
      
    )
  }
}

ecodeSDK.exp(HrmCard);