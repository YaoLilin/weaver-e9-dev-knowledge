const {WeaTools} = ecCom;
const callApi = WeaTools.callApi;
const HrmCard = ecodeSDK.imp(HrmCard);
const { inject, observer } = mobxReact;

@inject('hrmStore')
@observer
class HrmInfo extends React.Component{

  constructor(props){
    super(props);
  }

  componentDidMount(){
    debugger
    const {hrmStore} = this.props;
    hrmStore.init();
  }

  render(){
    const {hrmStore} = this.props;
    const {data} = hrmStore;
    return (
        <div style={{display:'flex',flexWrap: 'wrap',padding:'20px'}}>
          {
            data.map((item)=>{
              return <HrmCard key={item.id} data={item} />
            })
          }
        </div>      
    )
  }
}

ecodeSDK.exp(HrmInfo);