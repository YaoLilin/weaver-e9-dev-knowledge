"use strict";

var _dec, _class;

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaTools = _ecCom.WeaTools;
var callApi = WeaTools.callApi;
var HrmCard = ecodeSDK.imp(HrmCard);
var _mobxReact = mobxReact,
    inject = _mobxReact.inject,
    observer = _mobxReact.observer;
var HrmInfo = (_dec = inject('hrmStore'), _dec(_class = observer(_class =
/*#__PURE__*/
function (_React$Component) {
  _inherits(HrmInfo, _React$Component);

  function HrmInfo(props) {
    _classCallCheck(this, HrmInfo);

    return _possibleConstructorReturn(this, _getPrototypeOf(HrmInfo).call(this, props));
  }

  _createClass(HrmInfo, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      debugger;
      var hrmStore = this.props.hrmStore;
      hrmStore.init();
    }
  }, {
    key: "render",
    value: function render() {
      var hrmStore = this.props.hrmStore;
      var data = hrmStore.data;
      return React.createElement("div", {
        style: {
          display: 'flex',
          flexWrap: 'wrap',
          padding: '20px'
        }
      }, data.map(function (item) {
        return React.createElement(HrmCard, {
          key: item.id,
          data: item
        });
      }));
    }
  }]);

  return HrmInfo;
}(React.Component)) || _class) || _class);
ecodeSDK.exp(HrmInfo);